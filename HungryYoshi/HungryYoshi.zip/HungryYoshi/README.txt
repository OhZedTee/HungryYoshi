Before playing there are a few .dll's that need to be installed:

Microsoft Speeck SDK 11.0
Microsoft Kinect SDK 1.6
Camera2D XNA4 (Mr. Lane's DLL)

In order to play, you must open the game (either the executable, or run the game from the solution), and
you must open it every time to play. In order for the game to run, an Xbox 360 Kinect MUST be plugged into the computer.
This can be done with a Kinect Adapter, but without the Kinect plugged in, the game will not run! Veiw the manual for a 
list of different commands. Stay at least 10 feet away from the Kinect at all times. If the program crashes and doesn't
respond upon closing of the game, this is because of the Microsoft Kinect SDK 1.6 and it's incorrect use of 
multithreading. Please wait it out. It shouldn't take too long.

Hope you enjoy the game.